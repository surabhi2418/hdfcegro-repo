var urlParams = new URLSearchParams(window.location.search);
var landingURL = window.location.href;
var GAUID = '';

function Ltrim_string(objID) {
    var j = 0, k = 0;
    if (objID.length > 0) {
        for (var i = 0; i < objID.length && k < objID.length; i++) {
            if (objID.charAt(i) == " ") {
                j++;
            }
            else {
                k = objID.length;
            }
        }
        objID = objID.substring(j, objID.length);
    }
    return objID;
}

function CheckForWord(objID, strControlName, Word,ErrId) {
    var str = objID.value;
    if (str == Word) {
		document.getElementById(ErrId).innerHTML="Please Enter " + strControlName;
        return false;
    }
    return true;
}

function CheckBlank(objID, strControlName,ErrId) {
    if (Ltrim_string(objID.value) == "") {
        document.getElementById(ErrId).innerHTML="Please Enter " + strControlName;
        objID.value = "";
        return false;
    }
    return true;
}

function CheckSpecialAlphaOnly(objID, strControlName, spstr,ErrId) {
    var str = objID.value;
    var validchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" + spstr;

    if (spstr.toString().indexOf(" ") >= 0) {
        spstr = spstr.toString().replace(" ", "Space ");
    }

    if (CheckBlank(objID, strControlName)) {
        for (var j = 0; j < str.length; j++)
            if (validchars.indexOf(str.charAt(j)) == -1) {
				document.getElementById(ErrId).innerHTML="Please enter valid " + strControlName;
                objID.focus();
                objID.select();
                return false;
            }
        return true;
    }
}

function CheckLSpace(objID, strControlName,ErrId) {
    var chk = 0, len = 0;
    if (objID.value.length > 0) {
        len = objID.value.length;
        for (var i = 0; i <= len - 1; i++) {
            if (objID.value.charAt(i) == " ") {
                if (chk != 1) {
					document.getElementById(ErrId).innerHTML=strControlName + " : Spaces at the start are not allowed";
                    objID.focus();
                    objID.select();
                    return false;
                }
            }
            else
                chk = 1;
        }
    }
    return true;

}

function CheckMobileValidate(objControl, strControlName,ErrId) {
    var mobPat = /^(9|8|7|6)\d{9}$/;

    if (mobPat.test(objControl.value) == 0) {
		document.getElementById(ErrId).innerHTML="Please Enter valid Mobile No.";
        objControl.focus();
        return false;
    }
    else {
        return true;
    }
}

function FirstName(v_FirstName,ErrId) {
    if (!CheckForWord(v_FirstName, "Name", "Name",ErrId) || !CheckBlank(v_FirstName, "Name",ErrId) || !CheckSpecialAlphaOnly(v_FirstName, "Name", " .",ErrId) || !CheckLSpace(v_FirstName, "Name",ErrId)) {
        v_FirstName.focus();
        return !1
    } else {
        return !0
    }
}

function Phone(v_txtMobile,ErrId) {
    if (!CheckMobileValidate(v_txtMobile, "Mobile",ErrId)) {
        v_txtMobile.focus();
        $("#SendOtp").removeClass("hide");
        return !1
    } else if (!CheckMobileValidate(v_txtMobile, "Mobile Number",ErrId)) {
        v_txtMobile.focus();
        return !1
    } else {
        return !0
    }
}

function City(v_txtCity,ErrId) {
    if (!CheckForWord(v_txtCity, "City", "City*",ErrId) || !CheckBlank(v_txtCity, "City",ErrId) || !CheckLSpace(v_txtCity, "City",ErrId)) {
        v_txtCity.focus();
        return !1
    } else {
        return !0
    }
}

function CheckCheckBox(v_chkBox,ErrId) {
    var checked = $("#chkCallMe").is(":checked");
    if (v_chkBox.checked == !0) {
		document.getElementById(ErrId).innerHTML="";
        return !0
    }
    return !1
}

function ValidateFormat(number) {
    number = number.replace(/ /g, "").replace(/-/g, "");
    var retnumber = "";
    var numLength = number.length;
    switch (numLength) {
        case 5:
            retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 5);
            break;
        case 6:
            var isNumber = $.isNumeric(number.substring(4, 6));
            if (isNumber === true) {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 6);
            }
            else {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 5) + "-" + number.substring(5, 6);
            }
            break;
        case 7:
            var isNumber = $.isNumeric(number.substring(4, 7));
            if (isNumber === true) {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 7);
            }
            else {
                isNumber = $.isNumeric(number.substring(5, 7));
                if (isNumber === true) {
                    retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 5) + "-" + number.substring(5, 7);
                }
                else {
                    retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 6) + "-" + number.substring(6, 7);
                }
            }
            break;
        case 8:
            var isNumber = $.isNumeric(number.substring(5, 9));
            if (isNumber === true) {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 5) + "-" + number.substring(5, 9);
            }
            else {
                isNumber = $.isNumeric(number.substring(6, 9));
                if (isNumber === true) {
                    retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 6) + "-" + number.substring(6, 9);
                }
                else {
                    retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 7) + "-" + number.substring(7, 9);
                }
            }
            break;
        case 9:
            var isNumber = $.isNumeric(number.substring(5, 9));
            if (isNumber === true) {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 5) + "-" + number.substring(5, 9);
            }
            else {
                var isNumber = $.isNumeric(number.substring(6, 9));
                if (isNumber === true) {
                    retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 6) + "-" + number.substring(6, 9);
                }
                else {
                    retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 7) + "-" + number.substring(7, 9);
                }
            }
            break;
        case 10:
            var isNumber = $.isNumeric(number.substring(6, 10));
            if (isNumber === true) {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 6) + "-" + number.substring(6, 10);
            }
            else {
                retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 7) + "-" + number.substring(7, 10);
            }
            break;
        case 11:
            retnumber = number.substring(0, 2) + "-" + number.substring(2, 4) + "-" + number.substring(4, 7) + "-" + number.substring(7, 11);
            break;

        default:
            break;
    }
    return retnumber;
}

function validateNumber(number,id,ErrId) {
    var isValid = "";
    number = number.replace(/ /g, "-");
    var filter = /^[a-zA-Z]{2}-[0-9]{1}[a-zA-z0-9]{1}-[a-zA-Z0-9]([a-zA-Z0-9]){0,3}(-){0,1}([0-9]){0,4}$/;
    if (filter.test(number)) {
        isValid = number;
    }
    else {
        var retNum = ValidateFormat(number);
		document.getElementById("registration_vehicle"+id).value = retNum;
        if (filter.test(retNum)) {
            isValid = retNum;
        }
        else {
            isValid = "";
        }
    }
    return isValid;
}

function generate() {
        var d = new Date().getTime();
        
        var guid = 'xxxx-4xxx-yxx-xxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        
        return guid;
}

function resetErrMessages(id)
{
	document.getElementById('errName'+id).innerHTML="";
	document.getElementById('errMobile'+id).innerHTML="";
	document.getElementById('errRegNo'+id).innerHTML="";
	document.getElementById('errCity'+id).innerHTML="";
}

function MobNoCount(id) {

    var i = document.getElementById("txtMobno" + id).value.length;
    if (i == 10) {
        document.getElementById("SendOtp" + id).style.display = "block";
    } else {
        document.getElementById("SendOtp" + id).style.display = "none";
    }
}

function OtpCount(id) {
            var i = document.getElementById("txtVerifyOtp"+id).value.length;
            if (i == 6) {
                validateOTP(id);
            }
}
function ValidateRegNo(inputtxt) {
    var RegNo = /^([A-Z|a-z]{2}\s{1}\d{2}\s{1}[A-Z|a-z]{1,2}\s{1}\d{1,4})?([A-Z|a-z]{3}\s{1}\d{1,4})?$/;
    inputtxt = inputtxt.replace(new RegExp('-', 'g'), ' ');
    if (inputtxt.match(RegNo)) {

        return true;
    } else {
        return false;
    }
}
function validate(id) {
	resetErrMessages(id);
	document.getElementById("gif").style.visibility = "visible";
    var v_FristName = document.getElementById("txtName"+id);
    var v_txtMobile = document.getElementById("txtMobno"+id);
	var v_txtCity = document.getElementById("txtCity"+id);
    var v_chkBox = document.getElementById("chkCallMe"+id);
	var RegNo = document.getElementById("registration_vehicle"+id);
	var retValue = validateNumber(RegNo.value,id);
    var absURL = window.location.pathname.split('?')[0].replace("/campaigns/", "").replace(window.location.hash.substring(0), "").replace("#", "");
    if (!FirstName(v_FristName,'errName'+id)) {
		document.getElementById("gif").style.visibility = "hidden";
        return !1
    }
	else if (!Phone(v_txtMobile,'errMobile'+id)) {
		document.getElementById("gif").style.visibility = "hidden";
        return !1
    } 	
	else if (!City(v_txtCity,'errCity'+id)) {
		document.getElementById("gif").style.visibility = "hidden";
        return !1
	}
	
	else if (!CheckCheckBox(v_chkBox,'errDeclaration'+id)) {
		document.getElementById("gif").style.visibility = "hidden";
        return !1
    } else if (document.getElementById("VerificationMSG"+id).value != "1") {
		document.getElementById("gif").style.visibility = "hidden";
        alert("Please Verify OTP First.");
        return !1;
    } else {
		GAUID = generate();
        dataLayer.push({
            'event': 'event popup',
            'category': 'Car Insurance Old',
            'action': 'Account Lead',
            'label': 'Submit',
			'leadid':GAUID
        });
        document.getElementById("gif").style.visibility = "visible";
        redirectPage(id);
        return !0
    }
}

function redirectPage(id) {
    var v_FristName = document.getElementById("txtName" +id).value;
    var v_txtMobile = document.getElementById("txtMobno"+id).value;
    var v_ddlLocation = document.getElementById("txtCity"+id).value;
    var v_txtSI = "";
	var Event ="LP_LeadSubmitted" 
	var SectionName ="Top Banner"
	CARDS(Event,SectionName,v_txtMobile,v_ddlLocation,v_txtSI,GAUID);
	var RegNo = document.getElementById("registration_vehicle"+id).value;
    var absURL = window.location.pathname.split('?')[0].replace("/campaigns/", "").replace(window.location.hash.substring(0), "").replace("#", "");

     var data = {
        "Name": v_FristName,
        "Email": "",
        "Mobile": v_txtMobile,
        "City": v_ddlLocation,
        "LandingURL": landingURL,
        "UTM_Source": "SEO",
        "UTM_Campaign": "SEO",
        "Product": "PRIVATE CAR COMPREHENSIVE",
        "Page_ID": "CAR_INSURANCE_SEO",
        "CoverType": v_txtSI,
        "Tenure": "NA",
        "coverage": "NA",
		"GAUID":GAUID, 
		"LocationNo":"NA",
		"RegNo":RegNo,
        "GAclientid": "NA"
    };
    $('.loader').show();
    var apiurl1 = "https://www.hdfcergo.com/APIWrapper/api/Camp/InsertCarCampData";
    $.ajax({
        url: apiurl1,
        type: 'POST',
        data: data,
        success: function(data, textStatus, xhr) {
            if (xhr.status == "200") {
                if (data != "" && /<\/?[^>]*>/.test(data)) {
					var flag = (RegNo!='') ? '' : '1' ;
					document.getElementById("gif").style.visibility="visible";      
					var redirectURL = 'https://www.hdfcergo.com/OnlineInsurance/MotorOnline/Integration/InstantFastlaneIntegration';
					var data = '{ "Source": { "AgentCode": "FWD31003",  "UTM_Source": "Website",  "UTM_Medium": "Car Page",  "UTM_Camaign": "Online", "UTM_Content": "","UTM_Term": "" }, "Data": { "ContinueWithRegNo":"' + RegNo + '","ContinueWithOutRegNo": "' + flag + '",  "RenewWithPolicyNo": "", "RenewWithOutPolicyNo": "" ,"UniqueGUID":"'+GAUID+'"  }} ';
					var form = document.createElement("form");
					var element1 = document.createElement("input");
					form.method = "POST";
					form.action = redirectURL;
					element1.value = data;
					element1.name = "FastlaneJson";
					form.appendChild(element1);
					document.body.appendChild(form);
					form.submit();
					form.removeChild(element1);
					document.getElementById("gif").style.visibility = "hidden";
                }
                $('.loader').hide();

            }
        },
        error: function(xhr, textStatus, errorThrown) {
                      console.log('Error in Database');
			document.getElementById("gif").style.visibility = "hidden";
        }
    });

}


function SendOTP(id) {
        document.getElementById("gif").style.visibility = "visible";
        var v_txtMobile = document.getElementById("txtMobno" + id);
        if (!Phone(v_txtMobile,'errMobile'+id)) {
            document.getElementById("gif").style.visibility = "hidden";
            return !1
        } 
		else {
            var data = {
                "Mobile": v_txtMobile.value,
                "CheckSumID": ""
            };
            var apiurl1 = "https://www.hdfcergo.com/APIWrapper/api/OTP/SendOTP1";
            $.ajax({
                url: apiurl1,
                type: 'POST',
                data: data,
                success: function(data, textStatus, xhr) {
                    if (xhr.status == "200") {
                        var obj = JSON.parse(JSON.parse(data));
                        if (data != "") {
							   if (obj.Message != "Limit Exceeded") {
                            document.getElementById("reqid").value = obj.UNIQUEREQID;
                            $('#txtVerifyOtp' + id).attr("style", "display: inline !important");
							$("#verified" + id).hide();
                            //obj.Message = obj.Message.replace(' and email address te**@hdfcergo.com', '.');
                            //alert(obj.Message);
                        }
                        else if(obj.Message=='Limit Exceeded'){
					$('#OTPError' + id).text(obj.Message);
                    document.getElementById("OTPError" + id).style.display = "block";
					document.getElementById("gif").style.visibility = "hidden";
					}
						}else{
								   alert("Please try again after Sometime!");		
                        }
						document.getElementById("gif").style.visibility = "hidden";

                    }
                },
                error: function(xhr, textStatus, errorThrown) {
                    alert("Something Went Wrong!");
                    document.getElementById("gif").style.visibility = "hidden";
                }
            });
        }
    }

     function validateOTP(id) {
        document.getElementById("gif").style.visibility = "visible";
        var v_txtMobile = document.getElementById("txtMobno" + id);
        var v_txtOTP = document.getElementById("txtVerifyOtp" + id);
        var v_txtUID = document.getElementById("reqid");
        if (v_txtOTP.value == "") {
            document.getElementById("OTPError" + id).style.display = "block";
            document.getElementById("verified" + id).style.display = "none";
            document.getElementById("gif").style.visibility = "hidden";
        } 
		else {
            var data = {
                "OTP": v_txtOTP.value,
                "Input": v_txtMobile.value,
                "GUID": "",
                "UNIQUEREQID": v_txtUID.value
            };
            var apiurl1 = "https://www.hdfcergo.com/APIWrapper/api/OTP/ValidateOTP";
            $.ajax({
                url: apiurl1,
                type: 'POST',
                data: data,
                success: function(data, textStatus, xhr) {
				var obj = JSON.parse(JSON.parse(data));
				
                    if (xhr.status == "200") {
                        if (data.includes("true")) {
							$("#verified" + id).show();
							$("#txtVerifyOtp" + id).hide();
							document.getElementById("OTPError" + id).style.display = "none";
							$("#SendOtp" + id).hide();
                            document.getElementById("VerificationMSG" + id).value = "1";														
						}	
                        else if(obj.Message=='Limit Exceeded'){
					$("OTPError" + id).text(obj.Message);
                    document.getElementById("OTPError" + id).style.display = "block";
					document.getElementById("gif").style.visibility = "hidden";
					}						
						else {
                            //var obj = JSON.parse(JSON.parse(data));
							document.getElementById("OTPError" + id).style.display = "block";
							$("verified" + id).hide();
                            document.getElementById("VerificationMSG" + id).value = "0";
                        }
						}
                        document.getElementById("gif").style.visibility = "hidden";
                },
                error: function(xhr, textStatus, errorThrown) {
                    alert("Something Went Wrong!");
                    document.getElementById("gif").style.visibility = "hidden";
                }
				
            });

        }
    }