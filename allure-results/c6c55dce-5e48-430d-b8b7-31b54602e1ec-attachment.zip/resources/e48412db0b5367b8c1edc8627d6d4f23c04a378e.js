/* GAGTM Car */
function CARDS(event,sectionName,pageCategory,policyType)
{
window.dataLayer = window.dataLayer || [];
window.dataLayer.push({
 'event': event,
 'pageCategory': pageCategory,
 'productCategory': 'CarInsurance',
 'productName': '',
 'EID': '', 
 'MID': '',
 'policyType': policyType, 
 'sectionName': sectionName, 
 'coverSelected': '',
 'pvsCoverSelected': '',
 'pvsCoverStatus': '',
 'pvsNCBPercent': '',
 'addonsSelected': '',
 'transactionId': '',
 'premiumAmount': '',
 'vehicleModel': '',
 'vehicleVariant': '',
 'registrationYear': '',
 'registrationCity': '',
 'policyNumber': '',
 'sumInsured': '',
 'PACovered': '',
 'vehicleType': '',
 'leadId' : ''
});
return true;
}

/* Renewal */
function RenewExisting(){
var event ="BuyNow_RenewPol_Clicked"; 
var sectionName ="TopBanner";
var pageCategory ="ProductInformation";
var policyType ="Renewal";
CARDS(event,sectionName,pageCategory,policyType);
window.open('https://www.hdfcergo.com/renew-hdfc-ergo-policy', '_blank');
}

/* Open Quote Popup*/
function GetAQuote(sectionName) {
	var event = "BuyNow_GetQuote_Popup", pageCategory = "ProductInformation", policyType = "Fresh";
	CARDS(event,sectionName,pageCategory,policyType);
	quote_pupup.classList.add('show');
	bg_overly.classList.add('show');				
}

/* Close Quote Popup */
function ClosePopUp() {
	quote_pupup.classList.remove('show');
	bg_overly.classList.remove('show');
}

var PageLeadId = genPageLeadId();

/* Journey Redirection with Vehicle Number */
function VechileRegistration(vecno) {

	var event = "BuyNow_GetAQuote_Clicked";
    var pageCategory = "ProductInformation";
    var policyType = "Fresh";
    var sectionName = "";

    if (vecno.id == "popup-get-quote")
        sectionName = "QuotePopup";
    else
        sectionName = "TopBanner";
	
    regno = $($(vecno).parent().parent()).find('#registration_vehicle').val();
    var registrationVehicle;
    if (regno == undefined) { 
        regno = $($(vecno).parent().parent()).find('#registrationPopupVehicle').val();
        registrationVehicle = document.getElementById('registrationPopupVehicle');
    }
    else{
        registrationVehicle = document.getElementById('registration_vehicle');
    }
    regno = regno.trim();
    if (regno == "" || regno == undefined) {
        var x = document.getElementById("registration_vehicle");
        setErrorFor(registrationVehicle, 'Please enter valid registration number')
        return false;
    }
    else {
        var retValue = validateNumber(regno);
        if (retValue != "") {
			CARDS(event, sectionName, pageCategory, policyType);
			setErrorFor(registrationVehicle, '');
                     
			var redirectURL = ' https://www.hdfcergo.com/OnlineInsurance/MotorOnline/Integration/InstantFastlaneIntegration';
            var data = '{ "Source": { "AgentCode": "A0000033", "PageLeadID": "' + PageLeadId  + '",  "UTM_Source": "Website",  "UTM_Medium": "Car Page",  "UTM_Camaign": "Online", "UTM_Content": "","UTM_Term": "" }, "Data": { "ContinueWithRegNo":"' + retValue + '","ContinueWithOutRegNo": "",  "RenewWithPolicyNo": "", "RenewWithOutPolicyNo": "" ,"UniqueGUID":""  }} ';
            var form = document.createElement("form");
            var element1 = document.createElement("input");
            form.method = "POST";
            form.action = redirectURL;
            form.target = "_blank";
            element1.value = data;
            element1.name = "FastlaneJson";
            form.appendChild(element1);
            document.body.appendChild(form);
            form.submit();
            form.removeChild(element1);
			
            return false;
        }
        else {
            setErrorFor(registrationVehicle, 'Please enter valid registration number')
            return false;
        }
    }
}

/* Journey Redirection without Vehicle Number */
function VechilewithoutRegistration(regno) {
	
	var event = "BuyNow_NoCarNum_Clicked";
    var pageCategory = "ProductInformation";
    var policyType = "Fresh";
    var sectionName = "";

    if (regno.id == "popup-proceed-without-number")
        sectionName = "QuotePopup";
    else
        sectionName = "TopBanner";

    CARDS(event, sectionName, pageCategory, policyType);
	
	var redirectURL='https://www.hdfcergo.com/OnlineInsurance/MotorOnline/Integration/InstantFastlaneIntegration';
    var data='{   "Source": { "AgentCode": "A0000033", "PageLeadID": "' + PageLeadId  + '",  "UTM_Source": "Website",  "UTM_Medium": "Car Page",  "UTM_Camaign": "Online", "UTM_Content": "","UTM_Term": "" }, "Data": { "ContinueWithRegNo":"","ContinueWithOutRegNo": "1",  "RenewWithPolicyNo": "", "RenewWithOutPolicyNo": "" ,"UniqueGUID":""  }} ';
    var form = document.createElement("form");
    var element1 = document.createElement("input");
    form.method = "POST";
    form.action = redirectURL;
    form.target="_blank";
    element1.value = data ;
    element1.name = "FastlaneJson";
    form.appendChild(element1);
    document.body.appendChild(form);
    form.submit();
	form.removeChild(element1);
	
}

/* Validation functions: START */
function validateNumber(e) {
    var s = "";
    e = e.replace(/ /g, "-");
    var t = /^[a-zA-Z]{2}-[0-9]{1}[a-zA-z0-9]{1}-[a-zA-Z0-9]([a-zA-Z0-9]){0,3}(-){0,1}([0-9]){0,4}$/;

    if (!0 === $.isNumeric(e.substring(0, 2)))
        t = /^[0-9]{2}-[a-zA-Z]{2}-[a-zA-Z0-9]([0-9]){0,3}(-){0,1}([a-zA-Z]){0,2}$/;

    if (t.test(e))
        s = e;
    else {
        var n = ValidateFormat(e);
        s = t.test(n) ? n : "";
    }
    return s;
}

function ValidateFormat(e) {
    var s = "";

    e = e.replace(/ /g, "").replace(/-/g, "");

    var exp = !0 === $.isNumeric(e.substring(0, 2)) ? "bh" : e.length;

    switch (exp) {
        case 5:
            s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 5);
            break;
        case 6:
            s = !0 === $.isNumeric(e.substring(4, 6)) ? e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 6) : e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 5) + "-" + e.substring(5, 6);
            break;
        case 7:
            s = !0 === $.isNumeric(e.substring(4, 7)) ? e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 7) : !0 === $.isNumeric(e.substring(5, 7)) ? e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 5) + "-" + e.substring(5, 7) : e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 6) + "-" + e.substring(6, 7);
            break;
        case 8:
            s = !0 === $.isNumeric(e.substring(5, 9)) ? e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 5) + "-" + e.substring(5, 9) : !0 === $.isNumeric(e.substring(6, 9)) ? e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 6) + "-" + e.substring(6, 9) : e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 7) + "-" + e.substring(7, 9);
            break;
        case 9:
            if (!0 === $.isNumeric(e.substring(5, 9)))
                s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 5) + "-" + e.substring(5, 9);
            else
                s = !0 === $.isNumeric(e.substring(6, 9)) ? e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 6) + "-" + e.substring(6, 9) : e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 7) + "-" + e.substring(7, 9);
            break;
        case 10:
            if (!0 === $.isNumeric(e.substring(6, 10)))
                s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 6) + "-" + e.substring(6, 10);
            else
                s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 7) + "-" + e.substring(7, 10);
            break;
        case 11:
            s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 7) + "-" + e.substring(7, 11);
            break;
        case "bh":
            if (!0 === $.isNumeric(e.substring(0, 2)) && e.substring(2, 4).toLowerCase() == "bh" && !0 === $.isNumeric(e.substring(4, 8)) && !0 === isLetter(e.substring(8, 9)) && e.length == 9)
                s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 8) + "-" + e.substring(8, 9);
            else if (!0 === $.isNumeric(e.substring(0, 2)) && e.substring(2, 4).toLowerCase() == "bh" && !0 === $.isNumeric(e.substring(4, 8)) && !0 === isLetter(e.substring(8, 10)) && e.length == 10)
                s = e.substring(0, 2) + "-" + e.substring(2, 4) + "-" + e.substring(4, 8) + "-" + e.substring(8, 10);
            else
                s = "";
            break;
    }
    return s;
}

function isLetter(str) {
    var regex = /^[A-Za-z]+$/;

    return regex.test(str);
}

function setErrorFor(input, message) {
    var formControl = input.parentElement;
    var small = formControl.querySelector('small');
    formControl.className = 'form-box error'
    small.innerHTML = message;

}
/* Validation functions: END */

/* Other functions: START */
function formatDate(d)
{
    //get the month
    var month = d.getMonth();
    
	//get the day
    var day = d.getDate().toString();
    
	//get the year
    var year = d.getFullYear();
    
    //pull the last two digits of the year
    year = year.toString().substr(-2);
    
    //increment month by 1 since it is 0 indexed
    //converts month to a string
    month = (month + 1).toString();

    //if month is 1-9 pad right with a 0 for two digits
    if (month.length === 1)
        month = "0" + month;

    //if day is between 1-9 pad right with a 0 for two digits
    if (day.length === 1)
        day = "0" + day;

    //return the string "yymmdd"
    return year + month + day 
}

function genRandomNumber() {
	var minm = 10000;
	var maxm = 99999;
	return Math.floor(Math.random() * (maxm - minm + 1)) + minm;
}

function genPageLeadId() {
	var formattedDate = formatDate(new Date());
	var randomNumber = genRandomNumber();
	
	var UniqueId = parseInt('511' + formattedDate + '00000');
	UniqueId = UniqueId + randomNumber;
	return "PC" + UniqueId;
}

/* Other functions: END */