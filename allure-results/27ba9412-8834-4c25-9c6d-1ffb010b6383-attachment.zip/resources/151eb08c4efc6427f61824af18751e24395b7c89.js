// new select language js 

$(document).ready(function(){
	$("html").click(function(event) {
		$(".languagesSelect").removeClass("active");
	});
	$(".languagesSelect__btn").click(function() {
		event.stopPropagation();
		$(this).parent().toggleClass('active');
	});
	$(".languagesSelect .langOption").click(function(){ 
		$('.langOption__text').removeClass('activeOption');
		let selectedOption = $(this).children('.langOption__text');
		selectedOption.addClass('activeOption');
		let selectedOptionText =  $(this).children('.langOption__text').text();
		let selectDateDiv  =  $(this).closest('.languagesOptions').siblings('.languagesSelect__btn');
		selectDateDiv.find('.langOptnSelected__text').text(selectedOptionText);
	});
});



// old select language js 


var langCodeList = "english,hindiml,teluguml,bengaliml,marathiml,kannadaml,tamilml,gujaratiml";
document.onreadystatechange = function() {
	var Hostname = location.host;
	var lngDDL = document.getElementById("P9LngDdl");
	(s = window.location.pathname.substr(1).split("/")),
	(i = s[0]);
	if (langCodeList.indexOf(i) > -1) {
		if (i) {
			lngDDL.value = i;
		}
	}
};



$(document).ready(function() {
	var s = window.location.pathname.substr(1).split("/");
	var i = s[0];
	if (i == "hindiml") {
		var element1 = document.getElementById("english-toggle");
		element1.classList.remove("active");
		var element2 = document.getElementById("hindi-toggle");
		element2.classList.add("active");
		var element3 = document.getElementById("gujarati-toggle");
		element3.classList.remove("active");
		var element4 = document.getElementById("kannada-toggle");
		element4.classList.remove("active");
		var element5 = document.getElementById("tamil-toggle");
		element5.classList.remove("active");
		document.getElementById("deskToggle").setAttribute("style", "left:0; width: 50px; border: 1px solid #ddd;")
	} else if (i == "gujaratiml") {
		var element1 = document.getElementById("english-toggle");
		element1.classList.remove("active");
		var element2 = document.getElementById("hindi-toggle");
		element2.classList.remove("active");
		var element3 = document.getElementById("gujarati-toggle");
		element3.classList.add("active");
		var element4 = document.getElementById("kannada-toggle");
		element4.classList.remove("active");
		var element5 = document.getElementById("tamil-toggle");
		element5.classList.remove("active");
		document.getElementById("deskToggle").setAttribute("style", "left:calc(100% - 267px); width: 66px; border: 1px solid #ddd;");
	} else if (i == "tamilml") {
		var element1 = document.getElementById("english-toggle");
		element1.classList.remove("active");
		var element2 = document.getElementById("hindi-toggle");
		element2.classList.remove("active");
		var element3 = document.getElementById("gujarati-toggle");
		element3.classList.remove("active");
		var element4 = document.getElementById("kannada-toggle");
		element4.classList.remove("active");
		var element5 = document.getElementById("tamil-toggle");
		element5.classList.add("active");
		document.getElementById("deskToggle").setAttribute("style", "left:calc(100% - 200px); width:66px; border: 1px solid #ddd;");
	} else if (i == "kannadaml") {
		var element1 = document.getElementById("english-toggle");
		element1.classList.remove("active");
		var element2 = document.getElementById("hindi-toggle");
		element2.classList.remove("active");
		var element3 = document.getElementById("gujarati-toggle");
		element3.classList.remove("active");
		var element4 = document.getElementById("kannada-toggle");
		element4.classList.add("active");
		var element5 = document.getElementById("tamil-toggle");
		element5.classList.remove("active");
		document.getElementById("deskToggle").setAttribute("style", "left:calc(100% - 132px); width:66px; border: 1px solid #ddd;");
	} else {
		var element1 = document.getElementById("english-toggle");
		element1.classList.add("active");
		var element2 = document.getElementById("hindi-toggle");
		element2.classList.remove("active");
		var element3 = document.getElementById("gujarati-toggle");
		element3.classList.remove("active");
		var element4 = document.getElementById("kannada-toggle");
		element4.classList.remove("active");
		var element5 = document.getElementById("tamil-toggle");
		element5.classList.remove("active");
		document.getElementById("deskToggle").setAttribute("style", "left: calc(100% - 60px); width:65px; border: 1px solid #ddd;");
	}
});



document.onreadystatechange = function () {
var Hostname = location.host;
var lngDDL = document.getElementById("P9LngDdl");
s = window.location.pathname.substr(1).split("/"),
    i = s[0];
    if (langCodeList.indexOf(i) > -1) {
        if (i) {
            lngDDL.value = i;
        }
}
}

function SetLanguage() {
	var e = getMoxCookie("lang"),
	a = document.getElementById("P9LngDdl");
	e && window.location.pathname.indexOf(e) < 0 && RedirectUrl(e),
	e && a && (document.getElementById("P9LngDdl").value = e)
}
function ChangeLanguage(e) {
	var a = e.options[e.selectedIndex].value;
	removeMoxCookie("lang", ""),
	"English" != a && setMoxCookie("lang", a),
	RedirectUrl(a)
}
function RedirectUrl(e) {
 document.getElementById("gif").style.visibility = "visible";
	var a = "",
	s = window.location.pathname.substr(1).split("/"),
	i = s[0];
	if (langCodeList.indexOf(i) > -1)
		if ("English" == e)		
			s = s.slice(1), a = window.location.protocol + "//" + window.location.host + "/" + s.join("/");
		else {
			s[0] = e;
			var n = s.join("/");
			a = n == e ? window.location.protocol + "//" + window.location.host + "/" + n + "/" : window.location.protocol + "//" + window.location.host + "/" + n
		 document.getElementById("gif").style.visibility = "hidden";
		}
	else
		a = window.location.protocol + "//" + window.location.host + "/" + e + window.location.pathname;
	window.location = a
	 document.getElementById("gif").style.visibility = "hidden";
}
function setMoxCookie(e, a) {
	getMoxCookie(e)
}
function getMoxCookie(e) {
	var a = document.cookie.match("(^|;) ?" + e + "=([^;]*)(;|$)");
	return a ? a[2] : null
}
function removeMoxCookie(e) {
	document.cookie = "lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
}