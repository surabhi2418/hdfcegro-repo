BaseURL = "https://dia.hdfcergo.com/dia/assets/WebClient/";
iframeURL = "/";
var ey = document.getElementById("the_iframe");

function load(){
    $.ajax({
        type: 'GET',
        crossDomain: true,  
        url: BaseURL + "ChatbotClient.html",
        success: function (data) {
            var UserID = $("#UserID").val();           
            data = data.replace("$BaseURL$", BaseURL);
            renderBot(data);
        },
        complete: function (xhr, status) {
        },
        error: function (data) {
        }
    })
}
load();

function renderBot(html) {
    $("body").append($(html));
    dragElement(document.getElementById("Buddy"));
    $(".Buddy,.Ux_Close").click(function () {
        CloseApp();
    });
}

function dragElement(elmnt) {
    var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    if (document.getElementById(elmnt.id + "header")) {
        document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
    } else {
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        var right = 0;
        var $e = e;
        right = (window.innerWidth - e.clientX) - $(elmnt).width()
        var a = true;
        try {            
            a = $e.clientX > $(".BuddyChatBox.show").width() + 50
        } catch (e) {
            a = $e.clientX > 20;
        }
        if (right >= 20 && $e.clientX > 20 ) {
            elmnt.style.right = right + "px";
            if ($e.clientX > parseInt($(".BuddyChatBox").css("width").replace("px", "")) + 50)
                $(".BuddyChatBox").css("right", (right + 75) + "px");
        }
    }

    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}