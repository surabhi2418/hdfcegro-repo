var d = new Date();
d.setTime(d.getTime() + (2*365*24*60*60*1000));
var exp = d.toUTCString();
document.cookie = '_vz=viz_68e72823cf37f;path=/;domain=hdfcergo.com;expires='+exp;
